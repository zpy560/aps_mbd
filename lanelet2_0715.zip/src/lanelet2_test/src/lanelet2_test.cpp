#include <lanelet2_io/Io.h>
#include <lanelet2_projection/LocalCartesian.h>
#include <lanelet2_core/LaneletMap.h>
#include <iostream>
#include <lanelet2_core/geometry/impl/Lanelet.h>
#include "lanelet2_core/Forward.h"

int main()
{
    // 1. 指定osm文件路径
    std::string osm_file = "/home/byd-zpy/lanelet2_ws/src/lanelet2_test/map_file/new_lanelet2_maps_z0.osm";
    // std::string osm_file = "/home/byd-zpy/lanelet2_ws/src/lanelet2_test/map_file/map.osm";
    // std::string osm_file = "/home/byd-zpy/lanelet2_ws/src/lanelet2_test/map_file/byd_road.osm";
    lanelet::GPSPoint origin_gps{22.6881902, 114.3480115, 0.0};
    lanelet::Origin origin(origin_gps); // 例如杭州
    lanelet::projection::LocalCartesianProjector projector(origin);
    int i = 0;
    // 3. 读取地图
    lanelet::ErrorMessages errors;
    lanelet::LaneletMapPtr map = lanelet::load(osm_file, projector, &errors);
    auto &all_lanelets = map->laneletLayer;
    std::cout << "地图导入成功，lanelet数量: " << all_lanelets.size() << std::endl;

    // 3. 遍历Lanelet，打印ID与长度
    for (const auto &lanelet : all_lanelets)
    {
        i++;
        auto length = lanelet::geometry::length2d(lanelet);
        std::cout << i << " :" << "Lanelet ID: " << lanelet.id() << ", length: " << length << " meters\n";
    }

    // 保存所有元素到各自的数组
    std::vector<lanelet::Lanelet> lanelets(map->laneletLayer.begin(), map->laneletLayer.end());
    std::vector<lanelet::Point3d> points(map->pointLayer.begin(), map->pointLayer.end());
    std::vector<lanelet::LineString3d> linestrings(map->lineStringLayer.begin(), map->lineStringLayer.end());
    std::vector<lanelet::Polygon3d> polygons(map->polygonLayer.begin(), map->polygonLayer.end());
    std::vector<lanelet::Area> areas(map->areaLayer.begin(), map->areaLayer.end());

    std::cout << "Lanelet数量: " << lanelets.size() << std::endl;
    std::cout << "Point数量: " << points.size() << std::endl;
    std::cout << "LineString数量: " << linestrings.size() << std::endl;
    std::cout << "Polygon数量: " << polygons.size() << std::endl;
    std::cout << "Area数量: " << areas.size() << std::endl;

    for (const auto &point : points)
    {
        std::cout << "Point ID: " << point.id() << ", Coordinates: ";
        std::cout << "(" << point.x() << ", " << point.y() << ", " << point.z() << ") ";
        std::cout << std::endl;
    }

    for (const auto &linestring : linestrings)
    {
        std::cout << "LineString ID: " << linestring.id() << ", Points: ";
        for (auto it = linestring.begin(); it != linestring.end(); ++it)
        {
            std::cout << "(" << it->x() << ", " << it->y() << ", " << it->z() << ") ";
        }
        std::cout << std::endl;
    }

    for (const auto &polygon : polygons)
    {
        std::cout << "Polygon ID: " << polygon.id() << ", Points: ";
        for (const auto &point : polygon)
        {
            std::cout << "(" << point.x() << ", " << point.y() << ", " << point.z() << ") ";
        }
        std::cout << std::endl;
    }

    for (const auto &area : areas)
    {
        std::cout << "Area ID: " << area.id() << ", Polygons: ";
        for (const auto &linestring : area.outerBound())
        {
            for (auto it = linestring.begin(); it != linestring.end(); ++it)
            {
                std::cout << "(" << it->x() << ", " << it->y() << ", " << it->z() << ") ";
            }
        }
        std::cout << std::endl;
    }

    if (!errors.empty())
    {
        std::cerr << "导入过程中有错误:" << std::endl;
        for (const auto &err : errors)
        {
            std::cerr << err << std::endl;
        }
    }
    else
    {
        std::cout << "地图导入成功，lanelet数量: " << map->laneletLayer.size() << std::endl;
    }

    return 0;
}